// Create a new date from a string, return as a timestamp.
function timestamp(str) {
    return new Date(str).getTime();
}
