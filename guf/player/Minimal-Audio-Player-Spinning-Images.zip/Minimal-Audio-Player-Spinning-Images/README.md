# minimal-player
Minimal Player Inspiration

Live Demo: http://alikinvv.github.io/minimal-player/build
