var input = document.querySelector("#phone");
window.intlTelInput(input, {
  hiddenInput: "full_phone",
  utilsScript: "../../build/js/utils.js?1575016932390" // just for formatting/placeholders etc
});
