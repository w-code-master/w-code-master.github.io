var input = document.querySelector("#phone");
window.intlTelInput(input, {
  utilsScript: "../../build/js/utils.js?1575016932390" // just for formatting/placeholders etc
});
