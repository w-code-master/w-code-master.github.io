module.exports = {
	'testEnvironment': 'jsdom'
};
